data = readtable('accelerometer_log1.csv','VariableNamingRule','preserve');

signal_x = data{:,2};
signal_y = data{:,3};
signal_z = data{:,4};

% Remove NaN/Inf values
if any(~isfinite(signal_x))
    signal_x = fillmissing(signal_x, 'linear', 'EndValues', 'extrap');
end

if any(~isfinite(signal_y))
    signal_y = fillmissing(signal_y, 'linear', 'EndValues', 'extrap');
end

if any(~isfinite(signal_z))
    signal_z = fillmissing(signal_z, 'linear', 'EndValues', 'extrap');
end

% Filter design parameters
fs = 100;
fc = 5;
order = 4;
Wn = fc / (fs/2);
t = (0:length(signal_x)-1)/fs;

% Add high-frequency noise
noise = 0.5 * sin(2*pi*20*t)';
noisy_signal_x = signal_x + noise;
noisy_signal_y = signal_y + noise;
noisy_signal_z = signal_z + noise;

% 1. Discrete Fourier Transform Filtering
Y = fft(noisy_signal_x);
f = (0:length(Y)-1) * fs / length(Y);
Y_filtered = Y;
Y_filtered(f > fc & f < fs - fc) = 0;
signal_dft_x = real(ifft(Y_filtered));

Y = fft(noisy_signal_y);
f = (0:length(Y)-1) * fs / length(Y);
Y_filtered = Y;
Y_filtered(f > fc & f < fs - fc) = 0;
signal_dft_y = real(ifft(Y_filtered));

Y = fft(noisy_signal_z);
f = (0:length(Y)-1) * fs / length(Y);
Y_filtered = Y;
Y_filtered(f > fc & f < fs - fc) = 0;
signal_dft_z = real(ifft(Y_filtered));

% 2. Butterworth Low Pass Filter
[b,a] = butter(order, Wn, 'low');
signal_butter_x = filtfilt(b, a, noisy_signal_x);
signal_butter_y = filtfilt(b, a, noisy_signal_y);
signal_butter_z = filtfilt(b, a, noisy_signal_z);

% 3. Chebyshev Type I Low Pass Filter
[b,a] = cheby1(order, 1, Wn, 'low'); 
signal_cheby1_x = filtfilt(b, a, noisy_signal_x);
signal_cheby1_y = filtfilt(b, a, noisy_signal_y);
signal_cheby1_z = filtfilt(b, a, noisy_signal_z);

% 4. Chebyshev Type II Low Pass Filter
[b,a] = cheby2(order, 40, Wn, 'low'); 
signal_cheby2_x = filtfilt(b, a, noisy_signal_x);
signal_cheby2_y = filtfilt(b, a, noisy_signal_y);
signal_cheby2_z = filtfilt(b, a, noisy_signal_z);

% 5. Elliptic Low Pass Filter
[b,a] = ellip(order, 1, 40, Wn, 'low'); 
signal_ellip_x = filtfilt(b, a, noisy_signal_x);
signal_ellip_y = filtfilt(b, a, noisy_signal_y);
signal_ellip_z = filtfilt(b, a, noisy_signal_z);

% Plotting
figure;
subplot(3,2,1); plot(t, signal_x, 'k'); title('Original Signal X-axis');
subplot(3,2,2); plot(t, noisy_signal_x, 'c'); title('Noisy Signal X-axis');
subplot(3,2,3); plot(t, signal_y, 'k'); title('Original Signal Y-axis');
subplot(3,2,4); plot(t, noisy_signal_y, 'c'); title('Noisy Signal Y-axis');
subplot(3,2,5); plot(t, signal_z, 'k'); title('Original Signal Z-axis');
subplot(3,2,6); plot(t, noisy_signal_z, 'c'); title('Noisy Signal Z-axis');

figure;
subplot(3,1,1); plot(t, signal_dft_x, 'b'); title('DFT Filtered X-axis');
subplot(3,1,2); plot(t, signal_dft_y, 'g'); title('DFT Filtered Y-axis');
subplot(3,1,3); plot(t, signal_dft_z, 'r'); title('DFT Filtered Z-axis');

figure;
subplot(3,1,1); plot(t, signal_butter_x, 'b'); title('Butterworth Filtered X-axis');
subplot(3,1,2); plot(t, signal_butter_y, 'g'); title('Butterworth Filtered Y-axis');
subplot(3,1,3); plot(t, signal_butter_z, 'r'); title('Butterworth Filtered Z-axis');

figure;
subplot(3,1,1); plot(t, signal_cheby1_x, 'b'); title('Chebyshev Type I Filtered X-axis');
subplot(3,1,2); plot(t, signal_cheby1_y, 'g'); title('Chebyshev Type I Filtered Y-axis');
subplot(3,1,3); plot(t, signal_cheby1_z, 'r'); title('Chebyshev Type I Filtered Z-axis');

figure;
subplot(3,1,1); plot(t, signal_cheby2_x, 'b'); title('Chebyshev Type II Filtered X-axis');
subplot(3,1,2); plot(t, signal_cheby2_y, 'g'); title('Chebyshev Type II Filtered Y-axis');
subplot(3,1,3); plot(t, signal_cheby2_z, 'r'); title('Chebyshev Type II Filtered Z-axis');

figure;
subplot(3,1,1); plot(t, signal_ellip_x, 'b'); title('Elliptic Filtered X-axis');
subplot(3,1,2); plot(t, signal_ellip_y, 'g'); title('Elliptic Filtered Y-axis');
subplot(3,1,3); plot(t, signal_ellip_z, 'r'); title('Elliptic Filtered Z-axis');